# Bot proyecto computo ubicuo

Creación de un bot en telegram

## Config

1. Clonar Rpositorio
2. Instalar dependencias  usando "pip install -r requeriments.txt"
